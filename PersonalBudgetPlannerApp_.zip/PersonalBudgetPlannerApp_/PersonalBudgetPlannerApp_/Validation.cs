﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace PersonalBudgetPlannerApp_
{
    class Validation
    {
        public static bool validateCurrency(Canvas output, string input, SolidColorBrush normalColour)//checks that input from label is a currency in real time
        {
            bool value = false;
            SolidColorBrush error = new SolidColorBrush(Colors.Red);
            double temp;
            input.Replace(" ",""); //eliminates spaces so we  can parse to double
            string edited = input.Replace(".", ",");//replaces . with , so we can parse to double
           
            if (edited!="")
            {
                if (Double.TryParse(edited, out temp)) //checks input is double
                {
                    if (temp>=0) // checks that value is not negative as you do not get a negative currency
                    {
                        if (edited.Contains(","))// displays correct if no decimal. Runs if where theres a decimal point
                        {
                            if ((edited.Substring(edited.IndexOf(",")).Length <= 3) && !(edited.IndexOf(",") == edited.Length))
                            //makes sure decimal place is either 1,2 or none
                            {

                                ToolTipService.SetToolTip(output, "All correct"); //add tool tip to confirm correct input
                                output.Background = normalColour;//changes colour to normal to indicate to user input is correct                              
                                value = true;
                            }
                            else
                            {
                                output.Background = error;
                                ToolTipService.SetToolTip(output, "Max 2 decimal Places!"); //adds tool tip to txb for user to know error                               
                            }
                        }
                        else
                        {
                            output.Background = normalColour;//changes colour to normal to indicate to user input is correct                              
                            ToolTipService.SetToolTip(output, "All correct"); //add tool tip to confirm correct input
                            value = true;
                        }
                    }
                    else
                    {
                        output.Background = error;
                        ToolTipService.SetToolTip(output, "Value must be greater than or equal to 0"); //adds tool tip to txb for user to know error

                    }
                }
                else
                {
                 
                    output.Background = error;
                    ToolTipService.SetToolTip(output, "Value is not a valid number"); //adds tool tip to txb for user to know error
                }
            }
            else
            {
                output.Background = error;
                ToolTipService.SetToolTip(output, "Please enter a value!"); //adds tool tip to txb for user to know error  
            }
           
            
            return value;

        }

        public static string alterCurrency(string input)//Alters input from label so its format can be parsed to a string without error
        {
            string output = input.Replace(".", ",");
            output.Replace(" ", "") ;
            return output;
        }

        public static bool validateInterest(Canvas output, string input, SolidColorBrush normalColour)
        {
            bool value = false;
            input.Replace(" ", ""); //eliminates spaces so we  can parse to double
            string edited = input.Replace(".", ",");//replaces . with , so we can parse to double

            if (validateCurrency(output, edited, normalColour)==true)//call validate currency to insure value is a number of 2 decimal places max
            {
                //if input value is a number with 2 decimal places at most
       
                double temp = double.Parse(edited);
                if (temp>=1 && temp<=100)
                {
                    value = true;
                }
                else
                {
                    output.Background = new SolidColorBrush(Colors.Red);
                    ToolTipService.SetToolTip(output, "Value must be greater than 0 and less than or equal to 100"); //add tool tip to confirm correct input
                }
            }
            //if input is not of 2 decimal places the validateCurrency method will apply appropriate changes to canvas

            return value;
        }

        public static bool validateNumMon(Canvas output, string input, SolidColorBrush normalColour)
        {
            bool value = false;
            SolidColorBrush error = new SolidColorBrush(Colors.Red);
            //Adapted From: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/graphics-multimedia/wpf-brushes-overview?view=netframeworkdesktop-4.8
            // Date accessed 18 June
            //Author: Microsoft
            int temp;
            input.Replace(" ", ""); //eliminates spaces so we  can parse to double
            string edited = input.Replace(".", ",");//replaces . with , so we can parse to double

            if (edited != "")
            {
                if (Int32.TryParse(edited, out temp)) //checks input is double
                {
                    if (temp >0) // checks that value is not negative as you do not get a negative currency
                    {
                        output.Background = normalColour;
                        ToolTipService.SetToolTip(output, "All correct"); //adds tool tip to txb for user to know error
                        //Adapted From: https://stackoverflow.com/questions/11925113/how-add-and-show-tooltip-textbox-wpf-if-textbox-not-empty
                        // Date accessed 18 June
                        //Author: Matthijs
                                value = true;
                    }
                    else
                    {
                        output.Background = error;
                        ToolTipService.SetToolTip(output, "Value must be greater than 0"); //adds tool tip to txb for user to know error
                    }
                }
                else
                {

                    output.Background = error;
                    ToolTipService.SetToolTip(output, "Value is not a valid number."); //adds tool tip to txb for user to know error
                }
            }
            else
            {
                output.Background = error;
                ToolTipService.SetToolTip(output, "Please enter a value!"); //adds tool tip to txb for user to know error  
            }

            return value;
        }
        public static bool validateNumMon240360(Canvas output, string input, SolidColorBrush normalColour)
        {
            bool value = false;
            SolidColorBrush error = new SolidColorBrush(Colors.Red);
            int temp;
            input.Replace(" ", ""); //eliminates spaces so we  can parse to double
            string edited = input.Replace(".", ",");//replaces . with , so we can parse to double

            if (edited != "")
            {
                if (Int32.TryParse(edited, out temp)) //checks input is double
                {
                    if (temp >= 240 && temp <=360) // checks that value is not negative as you do not get a negative currency
                    {
                        output.Background = normalColour;
                        ToolTipService.SetToolTip(output, "All correct"); //adds tool tip to txb for user to know error
                        value = true;
                    }
                    else
                    {
                        output.Background = error;
                        ToolTipService.SetToolTip(output, "Value must be between or equal to 240 and 360"); //adds tool tip to txb for user to know error
                    }
                }
                else
                {

                    output.Background = error;
                    ToolTipService.SetToolTip(output, "Value is not a valid number."); //adds tool tip to txb for user to know error
                }
            }
            else
            {
                output.Background = error;
                ToolTipService.SetToolTip(output, "Please enter a value!"); //adds tool tip to txb for user to know error  
            }

            return value;

        }

        /****************** CODE ATTRIBUTION**********************************
         
           The following was adapted from Stackoverflow
           Author: Matthijs H
           

           The following was adapted from Mocrosoft
           Author:Microsoft
          
         */

    }
}
