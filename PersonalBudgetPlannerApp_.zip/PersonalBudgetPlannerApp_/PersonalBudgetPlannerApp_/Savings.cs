﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalBudgetPlannerApp_
{
    class Savings
    {
        //class for a Savings investment

        //create variables for Savings

        private double savingsTotal;
        private string purpose;
        private double interestRate;
        private int months;

        public Savings(double savingsTotal, string purpose, double interestRate, int months) //constructor for class
        {
            this.savingsTotal = savingsTotal;
            this.purpose = purpose;
            this.interestRate = interestRate;
            this.months = months;
        }

        public Savings() //empty constructor to create a savings object thats empty but can still be used to make a budget and added to or over wrtten later
        {

        }
        public double monthlySaving() //calculate the monthly savings deposit
        {
            /*
             A = P (1 + r) t + Df ((1 + r)t+1 -(1 + r))/ r

               P = initial principal, here this is 0 so fisrt term is 0
               D = deposit
               f = frequency of deposit, per year
               r = interest rate as a decimal
               t = number of years invested
               A = final amount, including the initial principal and all interest earned over t years
             * */
            double monthlySaving = 0;
            double r = interestRate / 100; 
            double numYears = (double) months / 12;
            int frequency = 12;
            double brackets = (Math.Pow((1 + r), numYears + 1) - (1 + r));
            monthlySaving = savingsTotal / (frequency*brackets/r);
            return Math.Round( monthlySaving,2);

            //uses formula from http://www.collegescholarships.org/calculators/compound-savings.php
        }

        public bool isEmpty() //checks if the object is "Empty" i.e has been made with empty constructor and has no values. Used in savings page when checking if a savings exists to display it
        {
            bool output = false;
            if (purpose == null)
            {
                output = true;
            }
            return output;
        }

        public string displaySavings() // returns all class variables and monthly deposit in a string
        {
            if (savingsTotal > 0)
            {
                return $"Savings: You require a monthly deposit of R{monthlySaving()} every month to have {savingsTotal} in {Math.Round((double)(months / 12), 2)} years with {interestRate}% interest for the purpose of: {purpose}";
            }
            else
            {
                return "";
            }
        }
    }
}
