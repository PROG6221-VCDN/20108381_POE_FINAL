﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Word = Microsoft.Office.Interop.Word;

namespace PersonalBudgetPlannerApp_
{
    /// <summary>
    /// Interaction logic for ShareWindow.xaml
    /// </summary>
    public partial class ShareWindow : Window
    {
        public ShareWindow()
        {
            InitializeComponent();
        }
        private void BtnTxt_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text file (*.txt)|*.txt";

            if (saveFileDialog.ShowDialog() == true)
                File.WriteAllText(saveFileDialog.FileName, UserBudget.currentBudget.displayBudget());
            //Adapted from: https://wpf-tutorial.com/dialogs/the-savefiledialog/
            //Date Accessed: 22 June
            // Author: wpf-tutorial
            this.Close();
        }

        private void BtnWord(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Word Documents|*.doc";

            if (saveFileDialog.ShowDialog() == true)
                File.WriteAllText(saveFileDialog.FileName, UserBudget.currentBudget.displayBudget());
            //Adapted From:https://docs.microsoft.com/en-us/dotnet/api/microsoft.win32.filedialog.filter?view=net-5.0
            //Date Accessed: 22 June
            //Author: Microsoft
            this.Close();
        }

        private void btnEmail_Click(object sender, RoutedEventArgs e)
        {
            Email newEmail = new Email(); //open page for an email
            newEmail.Show();
            this.Close();//close current page
        }
    }
}
