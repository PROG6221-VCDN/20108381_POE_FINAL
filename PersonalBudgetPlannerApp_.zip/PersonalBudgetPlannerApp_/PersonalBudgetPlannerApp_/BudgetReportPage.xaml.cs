﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PersonalBudgetPlannerApp_
{
    /// <summary>
    /// Interaction logic for BudgetReportPage.xaml
    /// </summary>
    public partial class BudgetReportPage : Page
    {
        public BudgetReportPage()
        {
            InitializeComponent();
            displayExpenses(); //call method to display all expenses when form loads. To make work easier and more effecient this is done in method
            displaySavings();// call method to display savings using method as this is easier and more effecient
        }

        public void displayExpenses()//displays all expenses in relevant txbs such that it is in descending order
        {
            //list is already sorted in descending order so the highest expense will be at index 0 and as you increase in the index of the list(1,2,3..)
            // the total for the expense at that index decreases
            txbHighest.Text = "";
            txbMedium.Text = "";
            txbLowest.Text = "";

            switch (UserBudget.currentBudget.UserExpenses.size()) //runs code depending on size of current budgets expense list
            {
                case 0: // if no expenses exist output error message in red to txb
                    txbHighest.Foreground =  new SolidColorBrush(Colors.Red);
                    txbHighest.Text = "No Expenses made yet. Please make an Expense first before trying to view them on a Budget Report";
                    break;
                case 1: // if theres 1 expense only display to highest txb
                    txbHighest.Text = "Highest Expense:\r\n" + UserBudget.currentBudget.UserExpenses.returnExpense(0); //set highest expense txb to highest expense @ index 0
                    changeColour(UserBudget.currentBudget.UserExpenses.returnSingleExpense(0), txbHighest);//sets colour of txb text to colour of the type of expense in the txb
                    break;
                case 2:// if theres 2 expense only display to highest and lowest txb
                    txbHighest.Text = "Highest Expense:\r\n" + UserBudget.currentBudget.UserExpenses.returnExpense(0); //set highest expense txb to highest expense @ index 0
                    changeColour(UserBudget.currentBudget.UserExpenses.returnSingleExpense(0), txbHighest);//sets colour of txb text to colour of the type of expense in the txb
                    txbLowest.Text = "Lowest Expense:\r\n" + UserBudget.currentBudget.UserExpenses.returnExpense(1);//set Lowest expense txb to highest expense @ index 1
                    changeColour(UserBudget.currentBudget.UserExpenses.returnSingleExpense(1), txbLowest);//sets colour of txb text to colour of the type of expense in the txb
                    break;
                case 3:// if theres 3 expenses display to all txbs
                    txbHighest.Text = "Highest Expense:\r\n" + UserBudget.currentBudget.UserExpenses.returnExpense(0);//set highest expense txb to highest expense @ index 0
                    changeColour(UserBudget.currentBudget.UserExpenses.returnSingleExpense(0), txbHighest);//sets colour of txb text to colour of the type of expense in the txb
                    txbMedium.Text = "Medium Expense:\r\n" + UserBudget.currentBudget.UserExpenses.returnExpense(1);//set medium expense txb to highest expense @ index 1
                    changeColour(UserBudget.currentBudget.UserExpenses.returnSingleExpense(1), txbMedium);//sets colour of txb text to colour of the type of expense in the txb
                    txbLowest.Text = "Lowest Expense:\r\n" + UserBudget.currentBudget.UserExpenses.returnExpense(2);//set lowest expense txb to highest expense @ index 2
                    changeColour(UserBudget.currentBudget.UserExpenses.returnSingleExpense(2), txbLowest);//sets colour of txb text to colour of the type of expense in the txb
                    break;

                default:
                    break;
            }

        }

        private void changeColour(Expenses temp, TextBox output) // changes txb text colour based on a given type 
        {
            Type currentType = temp.GetType();// gets type of expense input
  
            switch (temp) //checks type of child the temp expense is
            {

                case GenericExpenses g: //sets txb text to colour scheme of generic expense
                    output.Foreground = new SolidColorBrush(Color.FromRgb(253, 66, 125));

                    break;

                case Buy_Expense b://sets txb text to colour scheme of buy expenses
                   
                    output.Foreground = new SolidColorBrush(Color.FromRgb(121, 198, 132));

                    break;

                case Rent_Expense r://sets txb text to colour scheme of rent expenses
                    output.Foreground = new SolidColorBrush(Color.FromRgb(121, 198, 132));
                    break;

                case VehicleExpense v://sets txb text to colour scheme of vehicle expenses
                   
                    output.Foreground = new SolidColorBrush(Color.FromRgb(35, 141, 214));
                    break;

                default:
                    break;
            }

            
        }
        private void displaySavings() //sets savings txb to current savings if it exists
        {
            if (UserBudget.currentBudget.UserSavings.isEmpty() == false) //calls method to check if a savings exists
            {
                txbSavings.Text = UserBudget.currentBudget.UserSavings.displaySavings(); //set txb to savings
            }
            else
            {
                txbSavings.Text = ""; // set txb text to nothing
            }
        }

        private void btnShare_Click(object sender, RoutedEventArgs e)
        {
            ShareWindow newShare = new ShareWindow();//opens share window
            newShare.Show();//shows it
        }
    }
}
