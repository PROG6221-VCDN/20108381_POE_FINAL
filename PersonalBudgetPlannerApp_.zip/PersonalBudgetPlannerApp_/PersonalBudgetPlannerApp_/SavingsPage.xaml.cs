﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PersonalBudgetPlannerApp_
{
    /// <summary>
    /// Interaction logic for SavingsPage.xaml
    /// </summary>
    public partial class SavingsPage : Page
    {
        public SavingsPage()
        {
            InitializeComponent();
            if (UserBudget.currentBudget.UserSavings.isEmpty() == false)//checks if there already exists a Vehicle expenses
            {
                txbOutput.Text = UserBudget.currentBudget.UserSavings.displaySavings();//output current Vehicle expense for user to see
                MainWindow current = (MainWindow)App.Current.MainWindow; //create window object and assign active mainwindow to it            
                
                if (current.returnSavingsdeducted() == false) //if there is a savings check if its monthly deposit has been deducted from income
                {
                  btnDeduct.Visibility = Visibility.Visible;// sets delete button to visible as there is a Vehicle expense to delete
                }
                else
                {
                    btnDeduct.Visibility = Visibility.Hidden;
                }
            }
            else
            {
                txbOutput.Text = "";
                btnDeduct.Visibility = Visibility.Hidden;
            }

        }
        bool savingsTotal; // bool to check that savings total has been inputted
        bool purpose;// bool to check that purpose has been inputted
        bool interest;// bool to check that interest has been inputted
        bool months;// bool to check that months has been inputted

        SolidColorBrush backColour = new SolidColorBrush(Color.FromRgb(222, 111, 21));//set rgb value of backcolour theme for for form to brush

        public bool checkNull()//checks that all values needed have been entered by user
        {
            bool output = true;
            List<bool> checks = new List<bool> { savingsTotal, purpose, interest, months };//stores bool checks in list
            foreach (bool check in checks)//loops through list
            {
                if (check == false)//if one of the bool items in the list is false the set output to false and end loop
                {
                    output = false;
                    break;
                }
            }
            return output;
        }

        public void resetInputs()// resets input textboxes text and font, and panels color, all to default values
        {
            txbSavingstotal.Text = "Total Desired Amount";
            txbSavingstotal.FontStyle = FontStyles.Italic;
            txbPurpose.Text = "Savings Purpose";
            txbPurpose.FontStyle = FontStyles.Italic;         
            txbInterest.Text = "Interest Rate(%)";
            txbInterest.FontStyle = FontStyles.Italic;
            txbMonths.Text = "Total Months to Save Over";
            txbMonths.FontStyle = FontStyles.Italic;

            List<Canvas> outputPanels = new List<Canvas> { cvSavingstotal, cvPurpose, cvInterest, cvMonths};
            foreach (Panel item in outputPanels)
            {
                item.Background = backColour;
            }

        }

        private void txbSavingstotal_GotFocus(object sender, RoutedEventArgs e) //when you enter txt if placeholder txt is there
        {
            if (txbSavingstotal.Text == "Total Desired Amount")
            {
                txbSavingstotal.Text = "";
                txbSavingstotal.FontStyle = FontStyles.Normal;
            }
        }

        private void txbSavingstotal_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb without entering a value
        {
            if (txbSavingstotal.Text == "")
            {
                txbSavingstotal.Text = "Total Desired Amount";
                txbSavingstotal.FontStyle = FontStyles.Italic;
            }
        }

        private void txbPurpose_GotFocus(object sender, RoutedEventArgs e) //when you enter txt if placeholder txt is there
        {
            if (txbPurpose.Text == "Savings Purpose")
            {
                txbPurpose.Text = "";
                txbPurpose.FontStyle = FontStyles.Normal;
            }
        }

        private void txbPurpose_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb without entering a value
        {
            if (txbPurpose.Text == "")
            {
                txbPurpose.Text = "Savings Purpose";
                txbPurpose.FontStyle = FontStyles.Italic;
            }
        }

        private void txbInterest_GotFocus(object sender, RoutedEventArgs e) //when you enter txt if placeholder txt is there
        {
            if (txbInterest.Text == "Interest Rate(%)")
            {
                txbInterest.Text = "";
                txbInterest.FontStyle = FontStyles.Normal;
            }
        }

        private void txbInterest_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb without entering a value
        {
            if (txbInterest.Text == "")
            {
                txbInterest.Text = "Interest Rate(%)";
                txbInterest.FontStyle = FontStyles.Italic;
            }
        }

        private void txbMonths_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                months = Validation.validateNumMon(cvMonths, txbMonths.Text, backColour);
            }
            
        }

        private void txbMonths_GotFocus(object sender, RoutedEventArgs e) //when you enter txt if placeholder txt is there
        {
            if (txbMonths.Text == "Total Months to Save Over")
            {
                txbMonths.Text = "";
                txbMonths.FontStyle = FontStyles.Normal;
            }
        }

        private void txbMonths_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb without entering a value
        {
            if (txbMonths.Text == "")
            {
                txbMonths.Text = "Total Months to Save Over";
                txbMonths.FontStyle = FontStyles.Italic;
            }
        }

        private void txbSavingstotal_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                savingsTotal   = Validation.validateCurrency(cvSavingstotal, txbSavingstotal.Text, backColour);
            }
        }

        private void txbPurpose_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                if (txbPurpose.Text != "Savings Purpose")//txb cant be null because of placeholder text so check that text is different than placeholder
                {
                    purpose = true;
                }
            }
        }

        private void txbInterest_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                interest = Validation.validateInterest(cvInterest, txbInterest.Text, backColour);
            }
        }

        private void btn_Save_Click(object sender, RoutedEventArgs e)
        {
            
            if (checkNull())//if no entered values are null
                {
                    double totalSavings = double.Parse(Validation.alterCurrency(txbSavingstotal.Text));
                    string purpose = txbPurpose.Text;
                    double interest = double.Parse(Validation.alterCurrency(txbInterest.Text));
                    int months = Int32.Parse(Validation.alterCurrency(txbMonths.Text));
                    //get inputs for all variables to make a generic expense object. All inputs that call alterCurrency method from validation
                    // do so to ensure the input is in a correct format
                    Savings newSavings = new Savings(totalSavings,purpose,interest,months);
                    // make Savings object                   
                    UserBudget.currentBudget.UserSavings = newSavings;
                    //adds generic expense object to currentBudgets list of expenses
                    txbOutput.Text = newSavings.displaySavings();
                    //set output txb text to string display for Savings just made
                    btnDeduct.Visibility = Visibility.Visible;
                    //show delete as there is now an expense to delete
                    resetInputs();
                //reset inputs to default value
                MainWindow current = (MainWindow)App.Current.MainWindow; //create window object and assign active mainwindow to it            

                if (current.returnSavingsdeducted() == true) //previous savings was deducted
                {
                    current.setLiveIncome();//set live income with expenses only to make live income include only expenses and not now deleted Savings
                    current.setSavingsDedcuted(false); // change savings deducted to false as new savings hs not been deducted and old savings will be overwritten
                }

            }
                else
                {
                    MessageBox.Show("Incorrect currency format or a Value was not entered", "Input incorrect", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            
        
        }

        private void btnDeduct_Click(object sender, RoutedEventArgs e)
        {
            if (UserBudget.currentBudget.Month != "")
            {
                MainWindow current = (MainWindow)App.Current.MainWindow; //create window object and assign active mainwindow to it            

                current.setLiveIncomeSavingsExpense();
                btnDeduct.Visibility = Visibility.Hidden;// user has already deducted for current savings and can thus not do so anymore
            }
            else
            {
                MessageBox.Show("You have not selected a Month and income. Please do so before deducting your monthly savings investment", "No Income and Month made", MessageBoxButton.OK, MessageBoxImage.Error);
            }
           
        }
    }
}
