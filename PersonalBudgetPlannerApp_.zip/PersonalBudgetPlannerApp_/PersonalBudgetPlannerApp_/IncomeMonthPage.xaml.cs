﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PersonalBudgetPlannerApp_
{
    /// <summary>
    /// Interaction logic for IncomeMonthYear.xaml
    /// </summary>
    public partial class IncomeMonthYear : Page
    {
        public IncomeMonthYear()
        {
            InitializeComponent();
              
        }
        SolidColorBrush backColour = new SolidColorBrush(Color.FromRgb(251, 98, 81));//set rgb value of backcolour theme for for form to brush
        bool allCorrect = true; // bool to check that all inputs are correct. Only one is needed here as there is one txb value to enter
     
        public void resetInputs()// resets input textboxes text and font, and panels color, all to default values
        {
            txbIncome.Text = "Income";
            txbIncome.FontStyle = FontStyles.Italic;
            cvIncome.Background = backColour;
  
            cmbMonth.SelectedIndex = -1;
            //https://www.codeproject.com/Questions/1043701/How-to-reset-the-combobox-after-save-the-data
            
        }

   

        private void txbIncome_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and placeholder text is present
        {
            if (txbIncome.Text == "Income")
            {
                txbIncome.Text = "";
                txbIncome.FontStyle = FontStyles.Normal;
            }
            //https://www.infragistics.com/help/wpf/xamsyntaxeditor-changing-font-and-styles#_Ref332793137
        }

        private void txbIncome_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb having not entered a value
        {
            if (txbIncome.Text == "")
            {
                txbIncome.Text = "Income";
                txbIncome.FontStyle = FontStyles.Italic;
            }
        }

        private void txbIncome_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                allCorrect = Validation.validateCurrency(cvIncome, txbIncome.Text, backColour);
            }
            //https://stackoverflow.com/questions/7976554/textbox-textchanged-triggering-when-page-is-loaded-how-do-i-prevent-it
        }

        private void btn_Save_Click(object sender, RoutedEventArgs e)
        {
            if (allCorrect & cmbMonth.SelectedIndex > -1)//all values entered are correct and combobox item has been selected
            {
                double grossMonInc = double.Parse(Validation.alterCurrency(txbIncome.Text));//gets income from txb
                string month = cmbMonth.Text ;//gets month from cmb
                UserBudget.currentBudget.GrossMonInc = grossMonInc;//set static classes income to income user has entered
                UserBudget.currentBudget.Month = month;//set static classes month to month selected
                MainWindow current = (MainWindow)App.Current.MainWindow;
                resetInputs();//resets input to default values
                current.setLiveIncome(); // set live income as the income was changed 
                current.setMonth();// set month as month was changed
            }
            else
            {
                if (!allCorrect)
                {
                    MessageBox.Show("Incorrect currency  format", "Input incorrect", MessageBoxButton.OK, MessageBoxImage.Error);
                    //Adapted from: https://stackoverflow.com/questions/2109441/how-to-show-error-warning-message-box-in-net-how-to-customize-messagebox
                    //Author: Tides
                    //Date accessed: 29 April 2021
                }
                if (!(cmbMonth.SelectedIndex > -1))
                {
                    MessageBox.Show("You have not selected a Month. Please select a month for your budget", "No Month Selected",
                       MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }
        }

     
    }
}
