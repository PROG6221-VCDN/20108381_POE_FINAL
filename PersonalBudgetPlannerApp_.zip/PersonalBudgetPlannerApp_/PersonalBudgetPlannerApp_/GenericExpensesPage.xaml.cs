﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PersonalBudgetPlannerApp_
{
    /// <summary>
    /// Interaction logic for GenericExpensesPage.xaml
    /// </summary>
    public partial class GenericExpensesPage : Page
    {
        public GenericExpensesPage()
        {
            InitializeComponent();
           
            if (UserBudget.currentBudget.UserExpenses.containsType(generic))//checks if there already exists a generic expenses
            {
                btnDelete.Visibility = Visibility.Visible; // sets delete button to visible as there is a generic expense to delete
                txbOutput.Text = UserBudget.currentBudget.UserExpenses.returnExpenseDisplay(generic);//output current generic expense for user to see
            }
            else
            {
                btnDelete.Visibility = Visibility.Hidden; //no generic expense exists so hide delete button
                txbOutput.Text = "";//no generic expense exists so txb must be empty
            }
        }
        SolidColorBrush backColour = new SolidColorBrush(Color.FromRgb(253, 66, 125));//set rgb value of backcolour theme for for form to brush
        Type generic = typeof(GenericExpenses); //create a type for generic expenses to be used in checking if a generic expense already exists

        bool taxDed = false; //boolean to check if tax deduxtions has been entered or not
        bool groc = false;//boolean to check if groceries has been entered or not
        bool waterLights = false;//boolean to check if water and lights has been entered or not
        bool travel = false;//boolean to check if travel has been entered or not
        bool cellTell = false;//boolean to check if cellphone and telephonr has been entered or not
        bool other = false;//boolean to check if other has been entered or not
                           //all booleans set to false as they are not entered when form loads, only when user enters, thus we assume them to be not entered(false)
                           //until checked

        public bool checkNull() //checks that all values needed have been entered by user
        {
            bool output = true;
            List<bool> checks = new List<bool> { taxDed, groc, waterLights, travel, cellTell, other };//stores bools that check inputs in lists
            foreach (bool check in checks)
            {
                if (check == false) //if a bool in lst is false an input is null so we set output to false and end loop
                {
                    output = false;
                    break;
                }

            }
            return output;
        }

        public void resetInputs()// resets input textboxes text and font, and panels color, all to default values
        {
            txbTaxDed.Text = "Tax Deduction";
            txbTaxDed.FontStyle = FontStyles.Italic;
            txbGroc.Text = "Groceries";
            txbGroc.FontStyle = FontStyles.Italic;
            txbWaterLights.Text = "Water/Lights";
            txbWaterLights.FontStyle = FontStyles.Italic;
            txbTravel.Text = "Travel (including petrol)";
            txbTravel.FontStyle = FontStyles.Italic;
            txbCellTell.Text = "Cellphone/Telephone";
            txbCellTell.FontStyle = FontStyles.Italic;
            txbOther.Text = "Other";
            txbOther.FontStyle = FontStyles.Italic;
            List<Canvas> outputPanels = new List<Canvas> { cvTaxDed, cvGroc, cvWaterLights, cvTravel, cvCellTell, cvOther };//stores pnl's in list
            foreach (Panel item in outputPanels)
            {
                item.Background = backColour;//changes each pnl backcolout ot theme of frame
            }

        }

        private void txbTaxDed_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and the placeholder text is there
        {
            if (txbTaxDed.Text == "Tax Deduction")
            {
                txbTaxDed.Text = "";
                txbTaxDed.FontStyle = FontStyles.Normal;
            }
        }

        private void txbTaxDed_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txbTaxDed.Text == "")
            {
                txbTaxDed.Text = "Tax Deduction";
                txbTaxDed.FontStyle = FontStyles.Italic;
            }
        }

        private void txbGroc_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and the placeholder text is there
        {
            if (txbGroc.Text == "Groceries")
            {
                txbGroc.Text = "";
                txbGroc.FontStyle = FontStyles.Normal;
            }
        }

        private void txbGroc_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txbGroc.Text == "")
            {
                txbGroc.Text = "Groceries";
                txbGroc.FontStyle = FontStyles.Italic;
            }
        }

        private void txbWaterLights_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and the placeholder text is there
        {
            if (txbWaterLights.Text == "Water/Lights")
            {
                txbWaterLights.Text = "";
                txbWaterLights.FontStyle = FontStyles.Normal;
            }
        }

        private void txbWaterLights_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb having not entered a value
        {
            if (txbWaterLights.Text == "")
            {
                txbWaterLights.Text = "Water/Lights";
                txbWaterLights.FontStyle = FontStyles.Italic;
            }
        }

        private void txbTravel_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and the placeholder text is there
        {
            if (txbTravel.Text == "Travel (including petrol)")
            {
                txbTravel.Text = "";
                txbTravel.FontStyle = FontStyles.Normal;
            }
        }

        private void txbTravel_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb having not entered a value
        {
            if (txbTravel.Text == "")
            {
                txbTravel.Text = "Travel (including petrol)";
                txbTravel.FontStyle = FontStyles.Italic;
            }
        }

        private void txbCellTell_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and the placeholder text is there
        {
            if (txbCellTell.Text == "Cellphone/Telephone")
            {
                txbCellTell.Text = "";
                txbCellTell.FontStyle = FontStyles.Normal;
            }
        }

        private void txbCellTell_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb having not entered a value
        {
            if (txbCellTell.Text == "")
            {
                txbCellTell.Text = "Cellphone/Telephone";
                txbCellTell.FontStyle = FontStyles.Italic;
            }
        }

        private void txbOther_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and the placeholder text is there
        {
            if (txbOther.Text == "Other")
            {
                txbOther.Text = "";
                txbOther.FontStyle = FontStyles.Normal;
            }
        }

        private void txbOther_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb having not entered a value
        {
            if (txbOther.Text == "")
            {
                txbOther.Text = "Other";
                txbOther.FontStyle = FontStyles.Italic;
            }
        }

        private void txbTaxDed_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                taxDed = Validation.validateCurrency(cvTaxDed, txbTaxDed.Text, backColour);
            }
        }

        private void txbGroc_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                groc = Validation.validateCurrency(cvGroc, txbGroc.Text, backColour);
            }
        }

        private void txbWaterLights_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                waterLights = Validation.validateCurrency(cvWaterLights, txbWaterLights.Text, backColour);
            }
        }

        private void txbTravel_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                travel = Validation.validateCurrency(cvTravel, txbTravel.Text, backColour);
            }
        }

        private void txbCellTell_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
               cellTell = Validation.validateCurrency(cvCellTell, txbCellTell.Text, backColour);
            }
        }

        private void txbOther_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                other = Validation.validateCurrency(cvOther, txbOther.Text, backColour);
            }
        }

        private void btn_Save_Click(object sender, RoutedEventArgs e)
        {
            if (UserBudget.currentBudget.UserExpenses.containsType(generic) == false) // uses method to check that generic budget does not exist already
            {
                if (checkNull())//if no entered values are null
                {
                    double taxDed = double.Parse(Validation.alterCurrency(txbTaxDed.Text));
                    double groc = double.Parse(Validation.alterCurrency(txbGroc.Text));
                    double waterLights = double.Parse(Validation.alterCurrency(txbWaterLights.Text));
                    double travel = double.Parse(Validation.alterCurrency(txbTravel.Text));
                    double celltell = double.Parse(Validation.alterCurrency(txbCellTell.Text));
                    double other = double.Parse(Validation.alterCurrency(txbOther.Text));
                    //get inputs for all variables to make a generic expense object. All inputs that call alterCurrency method from validation
                    // do so to ensure the input is in a correct format
                    GenericExpenses newGeneric = new GenericExpenses(taxDed, groc, waterLights, travel, celltell, other);
                    // make generic expense object                   
                    UserBudget.currentBudget.UserExpenses.addExpense(newGeneric);
                    //adds generic expense object to currentBudgets list of expenses
                    txbOutput.Text = newGeneric.displayExpenses();
                    //set outbut txb text to string display for generic expense just made
                    btnDelete.Visibility = Visibility.Visible;
                    //show delete as there is now an expense to delete
                    resetInputs();
                    //reset inputs to default values
                    MainWindow current = (MainWindow)App.Current.MainWindow; //create window object and assign active mainwindow to it            
                    current.setLiveIncome();
                    //as an expense was added the remaining money has changed thus we call setLiveIncome to update this on the BudgetForm
                }
                else
                {
                    MessageBox.Show("Incorrect currency format or a Value was not entered", "Input incorrect", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("You already have a Generic expense. Please delete your current one first and try again",
                    "Generic Expense already exists", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            UserBudget.currentBudget.UserExpenses.deleteExpense(generic);//deletes expense of type generic from list of expenses
            MainWindow current = (MainWindow)App.Current.MainWindow;
            current.setLiveIncome();
            //as an expense was deleted the remaining money has changed thus we call setLiveIncome to update this on the BudgetForm
            txbOutput.Text = ""; // there is no longer an expense to display so set txb text to nothing
            resetInputs(); //resetInputs to ensure inputs are appropriate for a user to enter a new generic expense
            btnDelete.Visibility = Visibility.Hidden;// there is no longer an expense of generic to delete so the delete button must be unaccessible
        }
    }
}
