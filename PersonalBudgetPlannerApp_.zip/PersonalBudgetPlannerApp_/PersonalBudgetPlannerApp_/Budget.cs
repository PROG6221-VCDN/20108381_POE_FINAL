﻿using System;
using System.Collections.Generic;
using System.Text;


namespace  PersonalBudgetPlannerApp_

{ 
    class Budget
    {
        //class for buying expense

        //create variables for a budget
        private string month;
        private double grossMonInc;
        private ExpenseList userExpenses;
        private Savings userSavings;

        public Budget(string month, double grossMonInc, ExpenseList userExpenses, Savings userSavings)
        {
            this.month = month;
            this.grossMonInc = grossMonInc;
            this.userExpenses = userExpenses;
            this.userSavings = userSavings;
        }

        public string Month { get => month; set => month = value; } //getters and setters for month

        internal ExpenseList UserExpenses { get => userExpenses; set => userExpenses = value; }//getter and setters for expenseList
        public double GrossMonInc { get => grossMonInc; set => grossMonInc = value;  }//getters and setters for gross monthly income
        internal Savings UserSavings { get => userSavings; set => userSavings = value; }

        public double remMoney()// returns remaining money. Needed because when we add an expense the total income live must be updated
        {
            userExpenses.onExpenseMade(grossMonInc);  //call virtual void here as everytime the remaining money is effected, this method is called 
            return grossMonInc - userExpenses.returnTotexpenses();
        }      
         
        public double deductSavings() // needed because a user can choose to deduct the savings from gross mon inc or not, if they choose to do so, we must deduct
        {
            userExpenses.onExpenseMade(grossMonInc);  //call virtual void here as everytime the remaining money is effected, this method is called 
            return remMoney() - UserSavings.monthlySaving();//deduct savings from gross mon inc
        }
        public string displayBudget() //displays a whole budget as a string, used for sharing functions
        {
            string output = "";
            double savingsMonAmount = 0;
            if (userSavings.isEmpty() == false)
            {
                savingsMonAmount = UserSavings.monthlySaving();
            }
            output += $"BUDGET REPORT\n**********************************\nIncome: {grossMonInc}\nMonth: {month}\n" +
                $"{userExpenses.returnAllExpenses()} {UserSavings.displaySavings()}\n Total Money Remaining:{grossMonInc - userExpenses.returnTotexpenses() - savingsMonAmount}";
            return output;
        }
     }



}
