﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PersonalBudgetPlannerApp_
{
    /// <summary>
    /// Interaction logic for PropertyExpense.xaml
    /// </summary>
    public partial class PropertyExpense : Page
    {
        public PropertyExpense()
        {
            InitializeComponent();
            cvBuy.Visibility = Visibility.Hidden;
            cvRent.Visibility = Visibility.Hidden;
            if (UserBudget.currentBudget.UserExpenses.containsType(buy) || UserBudget.currentBudget.UserExpenses.containsType(rent))// if their already exists a buy expense 
            {
                if (UserBudget.currentBudget.UserExpenses.containsType(buy))
                {
                    txbOutput.Text = UserBudget.currentBudget.UserExpenses.returnExpenseDisplay(buy);//output buy expense for user to see

                }
                if (UserBudget.currentBudget.UserExpenses.containsType(rent))
                {
                    txbOutput.Text = UserBudget.currentBudget.UserExpenses.returnExpenseDisplay(rent);//output buy expense for user to see

                }
                btnDelete.Visibility = Visibility.Visible; // sets delete button to visible as there is a buy expense to delete
            }
            else
            {
                txbOutput.Text = "";
                btnDelete.Visibility = Visibility.Hidden;
            }        
            
        }
        bool monRent = false;//boolean to check if monthly rental amount has been entered or not
        bool purchPrice = false;//boolean to check if purchase price has been entered or not
        bool totDep = false;//boolean to check if property price has been entered or not
        bool interest;//boolean to check if interest rate has been entered or not
        bool monRepay;//boolean to check if numMonths has been entered or not
        SolidColorBrush backColour = new SolidColorBrush(Color.FromRgb(121, 198, 132));//set rgb value of backcolour theme for for form to brush
        Type buy = typeof(Buy_Expense);//create a type for buying expenses to be used in checking if a buying expense already exists
        Type rent = typeof(Rent_Expense);//create a type for rent expenses to be used in checking if a rent expense already exists

        public void resetInputs()// resets inputs by unselecting both rbs and triggering their code dor this event
        {
            rbBuy.IsChecked = false;
            rbRent.IsChecked = false;

        }

        public bool checkRentNull()//checks that all values needed for rent have been entered by user
        {
            bool output = true;
            if (monRent == false)
            {
                output = false;
            }
            return output;
        }

        public bool checkBuyNull()//checks that all values needed to buy have been entered by user
        {
            bool output = true;
            if (purchPrice == false || totDep == false || interest == false || monRepay ==false) //if any of the check bools are false
            {
                output = false;
            }
            return output;
        }

        private void txbMonRent_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and placeholder txt is present
        {
            if (txbMonRent.Text == "Monthly Rental Amount")
            {
                txbMonRent.Text = "";
                txbMonRent.FontStyle = FontStyles.Normal;
            }
        }

        private void txbMonRent_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb having not entered a value
        {
            if (txbMonRent.Text == "")
            {
                txbMonRent.Text = "Monthly Rental Amount";
                txbMonRent.FontStyle = FontStyles.Italic;
            }
        }

        private void txbPurchPrice_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and placeholder txt is present
        {
            if (txbPurchPrice.Text == "Purchase Price")
            {
                txbPurchPrice.Text = "";
                txbPurchPrice.FontStyle = FontStyles.Normal;
            }
        }

        private void txbPurchPrice_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb having not entered a value
        {
            if (txbPurchPrice.Text == "")
            {
                txbPurchPrice.Text = "Purchase Price";
                txbPurchPrice.FontStyle = FontStyles.Italic;
            }
        }

        private void txbTotDep_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and placeholder txt is present
        {
            if (txbTotDep.Text == "Total Deposit")
            {
                txbTotDep.Text = "";
                txbTotDep.FontStyle = FontStyles.Normal;
            }
        }

        private void txbTotDep_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb having not entered a value
        {
            if (txbTotDep.Text == "")
            {
                txbTotDep.Text = "Total Deposit";
                txbTotDep.FontStyle = FontStyles.Italic;
            }
        }

        private void txbIntRate_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and placeholder txt is present
        {
            if (txbIntRate.Text == "Interest Rate(%)")
            {
                txbIntRate.Text = "";
                txbIntRate.FontStyle = FontStyles.Normal;
            }
        }

        private void txbMonRepay_GotFocus(object sender, RoutedEventArgs e)//if user enters txb and placeholder txt is present
        {
            if (txbMonRepay.Text == "Months to Repay(240-360)")
            {
                txbMonRepay.Text = "";
                txbMonRepay.FontStyle = FontStyles.Normal;
            }
        }

        private void txbMonRepay_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb having not entered a value
        {
            if (txbMonRepay.Text == "")
            {
                txbMonRepay.Text = "Months to Repay(240-360)";
                txbMonRepay.FontStyle = FontStyles.Italic;
            }
        }

        private void txbIntRate_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb having not entered a value
        {
            if (txbIntRate.Text == "")
            {
                txbIntRate.Text = "Interest Rate(%)";
                txbIntRate.FontStyle = FontStyles.Italic;
            }
        }

        private void rbRent_Checked(object sender, RoutedEventArgs e)
        {
          
                rbBuy.IsChecked = false; //uncheck rbbuy as rent is checked
                cvRent.Visibility = Visibility.Visible;//make rent components visivle
          
          
        }

        private void rbBuy_Checked(object sender, RoutedEventArgs e)
        {
            
                rbRent.IsChecked = false;//make rent unchecked
                cvBuy.Visibility = Visibility.Visible;//make buy components visible
            
        
        }

        private void rbBuy_Unchecked(object sender, RoutedEventArgs e) //reset all inputs in buy canvas to default
        {
            cvBuy.Visibility = Visibility.Hidden;
            txbPurchPrice.Text = "Purchase Price";
            txbPurchPrice.FontStyle = FontStyles.Italic;
            txbTotDep.Text = "Total Deposit";
            txbTotDep.FontStyle = FontStyles.Italic;
            txbIntRate.Text = "Interest Rate(%)";
            txbIntRate.FontStyle = FontStyles.Italic;
            txbMonRepay.Text = "Months to Repay(240-360)";
            txbMonRepay.FontStyle = FontStyles.Italic;
            List<Canvas> outputPanels = new List<Canvas> { cvPurchPrice,cvTotDep,cvIntRate,cvMonRepay };//stores pnl's in list
            foreach (Panel item in outputPanels)
            {
                item.Background = backColour;//changes each pnl backcolout ot theme of frame
            }
        }

        private void rbRent_Unchecked(object sender, RoutedEventArgs e)//reset all inputs in rent canvas to default
        {
            cvRent.Visibility = Visibility.Hidden;
            txbMonRent.Text = "Monthly Rental Amount";
            txbMonRent.FontStyle = FontStyles.Italic;
            cvMonRent.Background = backColour;
        }

        private void txbMonRent_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                monRent = Validation.validateCurrency(cvMonRent, txbMonRent.Text, backColour);
            }
        }

        private void txbPurchPrice_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
               purchPrice = Validation.validateCurrency(cvPurchPrice, txbPurchPrice.Text, backColour);
            }
        }

        private void txbTotDep_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                totDep = Validation.validateCurrency(cvTotDep, txbTotDep.Text, backColour);
            }
        }

        private void txbIntRate_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                interest = Validation.validateInterest(cvIntRate, txbIntRate.Text, backColour);
            }
        }

        private void txbMonRepay_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                monRepay = Validation.validateNumMon240360(cvMonRepay, txbMonRepay.Text, backColour);
            }
        }

        private void btn_Save_Click(object sender, RoutedEventArgs e)
        {
            if (!(UserBudget.currentBudget.UserExpenses.containsType(buy) || UserBudget.currentBudget.UserExpenses.containsType(rent)))
            {   //if there does not exist a buy or rent
                if (rbBuy.IsChecked ==true || rbRent.IsChecked == true) //if one of the rb is selected
                {
                    if (rbRent.IsChecked == true)//if rent is checked
                    {
                        if (checkRentNull()) //if unputs are not null
                        {
                            double monRent = double.Parse(Validation.alterCurrency(txbMonRent.Text));
                            //get input for rent expense
                            Rent_Expense newRent = new Rent_Expense(monRent);
                            //make rent expense
                            UserBudget.currentBudget.UserExpenses.addExpense(newRent);
                            //add rent expense to expense list
                            txbOutput.Text = newRent.displayExpenses();
                            //set output text to rent expense string display
                            btnDelete.Visibility = Visibility.Visible;
                            //make delete visible as their is now a rent expense to delete
                            resetInputs();
                            //reset inputs to default values
                            MainWindow current = (MainWindow)App.Current.MainWindow; //create window object and assign active mainwindow to it          
                            current.setLiveIncome();
                            //as an expense was added the remaining money has changed thus we call setLiveIncome to update this on the BudgetForm
                        }
                        else
                        {
                            MessageBox.Show("Incorrect currency format or a Value was not entered", "Input incorrect", MessageBoxButton.OK, MessageBoxImage.Error);
                        }

                    }
                    if (rbBuy.IsChecked ==true) //if buy is checked
                    {
                        if (checkBuyNull())
                        {
                            double purchPrice = double.Parse(Validation.alterCurrency(txbPurchPrice.Text));
                            double totDep = double.Parse(Validation.alterCurrency(txbTotDep.Text));
                            double intRate = double.Parse(Validation.alterCurrency(txbIntRate.Text));
                            double monRepay = double.Parse(Validation.alterCurrency(txbMonRepay.Text));
                            //get input for a buy expense
                            Buy_Expense newBuy = new Buy_Expense(purchPrice, totDep, intRate, monRepay);
                            //make buy expense
                            UserBudget.currentBudget.UserExpenses.addExpense(newBuy);
                            //add buy expense to expense list
                            newBuy.homeLoanWarning(UserBudget.currentBudget.GrossMonInc);
                            //call homeloan warning for buy expense
                            txbOutput.Text = newBuy.displayExpenses();
                            //set output text to buy expense string display
                            btnDelete.Visibility = Visibility.Visible;
                            //make delete visible as their is now a rent expense to delete
                            resetInputs();
                            //reset inputs to default values
                            MainWindow current = (MainWindow)App.Current.MainWindow; //create window object and assign active mainwindow to it          
                            current.setLiveIncome();
                            //as an expense was added the remaining money has changed thus we call setLiveIncome to update this on the BudgetForm
                        }
                        else
                        {
                            MessageBox.Show("Incorrect currency format or a Value was not entered", "Input incorrect", MessageBoxButton.OK, MessageBoxImage.Error);
                        }

                    }
                }
                else
                {
                    MessageBox.Show("You have not selected a property type. Please select Buy or Rent", "No poperty type selected", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("You already have a Property expense. Please delete your current one first and try again",
                           "Property Expense already exists", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (UserBudget.currentBudget.UserExpenses.containsType(buy)) // if there exists a buy expense
            {
                UserBudget.currentBudget.UserExpenses.deleteExpense(buy);//deletes expense of type buy from list of expenses
                MainWindow current = (MainWindow)App.Current.MainWindow; //create window object and assign active mainwindow to it 
                current.setLiveIncome(); //set live income as an expense was deleted so remaining money has changed
                txbOutput.Text = "";//there is no expense to display so set output txb text to nothing
                resetInputs();//resetInputs to ensure inputs are appropriate for a user to enter a new generic expense
                btnDelete.Visibility = Visibility.Hidden;// there is no longer an expense of buying to delete so the delete button must be unaccessible
            }
            if (UserBudget.currentBudget.UserExpenses.containsType(rent))// if there exists a buy expense
            {
                UserBudget.currentBudget.UserExpenses.deleteExpense(rent);//deletes expense of type rent from list of expenses
                MainWindow current = (MainWindow)App.Current.MainWindow; //create window object and assign active mainwindow to it 
                current.setLiveIncome();//set live income as an expense was deleted so remaining money has changed
                txbOutput.Text = "";//there is no expense to display so set output txb text to nothing
                resetInputs();//resetInputs to ensure inputs are appropriate for a user to enter a new generic expense
                btnDelete.Visibility = Visibility.Hidden;// there is no longer an expense of rent to delete so the delete button must be unaccessible
            }
        }
    }
}
