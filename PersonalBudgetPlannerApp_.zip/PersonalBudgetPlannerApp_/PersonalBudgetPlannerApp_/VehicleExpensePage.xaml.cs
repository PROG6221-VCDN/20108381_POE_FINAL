﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PersonalBudgetPlannerApp_
{
    /// <summary>
    /// Interaction logic for VehicleExpensePage.xaml
    /// </summary>
    public partial class VehicleExpensePage : Page
    {
        public VehicleExpensePage()
        {
            InitializeComponent();
            if (UserBudget.currentBudget.UserExpenses.containsType(vehicle))//checks if there already exists a Vehicle expenses
            {
                btnDelete.Visibility = Visibility.Visible;// sets delete button to visible as there is a Vehicle expense to delete
                txbOutput.Text = UserBudget.currentBudget.UserExpenses.returnExpenseDisplay(vehicle);//output current Vehicle expense for user to see
            }
            else
            {
                txbOutput.Text = "";
                btnDelete.Visibility = Visibility.Hidden;
            }
           
        }
        bool make = false;//boolean to check if make has been entered or not
        bool model = false;//boolean to check if model has been entered or not
        bool purchPrice = false;//boolean to check if purchise price has been entered or not
        bool totDeopsit = false;//boolean to check if total deposit has been entered or not
        bool interest = false;//boolean to check if interest premium has been entered or not
        bool insurancePrem = false;
        SolidColorBrush backColour = new SolidColorBrush(Color.FromRgb(35, 141, 214));//set rgb value of backcolour theme for for form to brush
        Type vehicle = typeof(VehicleExpense); //create a type for generic expenses to be used in checking if a generic expense already exists
        private void txbMake_GotFocus(object sender, RoutedEventArgs e)//if user entrs txb and placeholder text is there
        {
            if (txbMake.Text == "Make")
            {
                txbMake.Text = "";
                txbMake.FontStyle = FontStyles.Normal;
            }
        }

        public bool checkNull()//checks that all values needed have been entered by user
        {
            bool output = true;
            List<bool> checks = new List<bool> { make, model, purchPrice, totDeopsit, interest, insurancePrem };//stores bool checks in list
            foreach (bool check in checks)//loops through list
            {
                if (check == false)//if one of the bool items in the list is false the set output to false and end loop
                {
                    output = false;
                    break;
                }
            }
            return output;
        }

        public void resetInputs()// resets input textboxes text and font, and panels color, all to default values
        {
            txbMake.Text = "Make";
            txbMake.FontStyle = FontStyles.Italic;
            txbModel.Text = "Model";
            txbModel.FontStyle = FontStyles.Italic;
            txbPurchPrice.Text = "Purchase Price";
            txbPurchPrice.FontStyle = FontStyles.Italic;
            txbTotDep.Text = "Total Deposit";
            txbTotDep.FontStyle = FontStyles.Italic;
            txbInterest.Text = "Interest Rate(%)";
            txbInterest.FontStyle = FontStyles.Italic;
            txbInsurance.Text = "Insurance Premium";
            txbInsurance.FontStyle = FontStyles.Italic;
            List<Canvas> outputPanels = new List<Canvas> {cvPurchPrice, cvTotDep, cvInterest,cvInsurance };
            foreach (Panel item in outputPanels)
            {
                item.Background = backColour;
            }

        }
        private void txbMake_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb not entering anything
        {
            if (txbMake.Text == "")
            {
                txbMake.Text = "Make";
                txbMake.FontStyle = FontStyles.Italic;
            }
        }

        private void txbModel_GotFocus(object sender, RoutedEventArgs e)//if user entrs txb and placeholder text is there
        {
            if (txbModel.Text == "Model")
            {
                txbModel.Text = "";
                txbModel.FontStyle = FontStyles.Normal;
            }
        }

        private void txbModel_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb not entering anything
        {
            if (txbModel.Text == "")
            {
                txbModel.Text = "Model";
                txbModel.FontStyle = FontStyles.Italic;
            }
        }

        private void txbPurchPrice_GotFocus(object sender, RoutedEventArgs e)//if user entrs txb and placeholder text is there
        {
            if (txbPurchPrice.Text == "Purchase Price")
            {
                txbPurchPrice.Text = "";
                txbPurchPrice.FontStyle = FontStyles.Normal;
            }
        }

        private void txbPurchPrice_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb not entering anything
        {
            if (txbPurchPrice.Text == "")
            {
                txbPurchPrice.Text = "Purchase Price";
                txbPurchPrice.FontStyle = FontStyles.Italic;
            }
        }

        private void txbTotDep_GotFocus(object sender, RoutedEventArgs e)//if user entrs txb and placeholder text is there
        {
            if (txbTotDep.Text == "Total Deposit")
            {
                txbTotDep.Text = "";
                txbTotDep.FontStyle = FontStyles.Normal;
            }
        }

        private void txbTotDep_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb not entering anything
        {
            if (txbTotDep.Text == "")
            {
                txbTotDep.Text = "Total Deposit";
                txbTotDep.FontStyle = FontStyles.Italic;
            }
        }

        private void txbInterest_GotFocus(object sender, RoutedEventArgs e)//if user entrs txb and placeholder text is there
        {
            if (txbInterest.Text == "Interest Rate(%)")
            {
                txbInterest.Text = "";
                txbInterest.FontStyle = FontStyles.Normal;
            }
        }

        private void txbInterest_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb not entering anything
        {
            if (txbInterest.Text == "")
            {
                txbInterest.Text = "Interest Rate(%)";
                txbInterest.FontStyle = FontStyles.Italic;
            }
        }

        private void txbInsurance_GotFocus(object sender, RoutedEventArgs e)//if user entrs txb and placeholder text is there
        {
            if (txbInsurance.Text == "Insurance Premium")
            {
                txbInsurance.Text = "";
                txbInsurance.FontStyle = FontStyles.Normal;
            }
        }

        private void txbInsurance_LostFocus(object sender, RoutedEventArgs e)//if user leaves txb not entering anything
        {
            if (txbInsurance.Text == "")
            {
                txbInsurance.Text = "Insurance Premium";
                txbInsurance.FontStyle = FontStyles.Italic;
            }
        }

        private void txbMake_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                if (txbMake.Text != "Make")//txb cant be null because of placeholder text so check that text is different than placeholder
                {
                    make = true;
                }
            }
        }

        private void txbModel_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                if (txbModel.Text != "Model")//txb cant be null because of placeholder text so check that text is different than placeholder
                {
                    model = true;
                }
            }
        }

        private void txbPurchPrice_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                purchPrice = Validation.validateCurrency(cvPurchPrice, txbPurchPrice.Text, backColour);
            }
        }

        private void txbTotDep_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                totDeopsit = Validation.validateCurrency(cvTotDep, txbTotDep.Text, backColour);
            }
        }

        private void txbInterest_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                interest = Validation.validateInterest(cvInterest, txbInterest.Text, backColour);
            }
        }

        private void txbInsurance_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.IsLoaded) //text changed events will run even when text is set in xaml so here we ensure the page is completely loaded
            {
                insurancePrem = Validation.validateCurrency(cvInsurance, txbInsurance.Text, backColour);
            }
        }

        private void btn_Save_Click(object sender, RoutedEventArgs e)
        {
            if (UserBudget.currentBudget.UserExpenses.containsType(vehicle) == false)//if there does not already exist a vehicle expense
            {
                if (checkNull()) //if all inputs are not null
                {
                    string make = txbMake.Text;
                    string model = txbModel.Text;
                    double purchasePrice = double.Parse(Validation.alterCurrency(txbPurchPrice.Text));
                    double totDeposit = double.Parse(Validation.alterCurrency(txbTotDep.Text));
                    double interestRate = double.Parse(Validation.alterCurrency(txbInterest.Text));
                    double insurancePrem = double.Parse(Validation.alterCurrency(txbInsurance.Text));
                    //get inputs for a vehicle expense
                    VehicleExpense newVehicle = new VehicleExpense(make, model, purchasePrice, totDeposit, interestRate, insurancePrem);
                    //make vehicle expense
                    UserBudget.currentBudget.UserExpenses.addExpense(newVehicle);
                    //add vehcle expense to expense list
                    txbOutput.Text = newVehicle.displayExpenses();
                    //set outbut txb text to string display for vehicle expense just made
                    btnDelete.Visibility = Visibility.Visible;
                    //show delete as there is now an expense to delete
                    resetInputs();
                    //reset inputs to default values
                    MainWindow current = (MainWindow)App.Current.MainWindow; //create window object and assign active mainwindow to it  
                    current.setLiveIncome();
                    //as an expense was added the remaining money has changed thus we call setLiveIncome to update this on the BudgetForm

                }
                else
                {

                    MessageBox.Show("Incorrect currency format or a Value was not entered", "Input incorrect", MessageBoxButton.OK, MessageBoxImage.Error);


                }
            }
            else
            {
                MessageBox.Show("You already have a Vehicle expense. Please delete your current one first and try again",
                    "Vehicle Expense already exists", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            UserBudget.currentBudget.UserExpenses.deleteExpense(vehicle);//deletes expense of type vehicle from list of expenses
            MainWindow current = (MainWindow)App.Current.MainWindow; //create window object and assign active mainwindow to it  
            current.setLiveIncome();
            //as an expense was deleted the remaining money has changed thus we call setLiveIncome to update this on the BudgetForm
            txbOutput.Text = "";
            // there is no longer an expense to display so set txb text to nothing
            resetInputs();
            //resetInputs to ensure inputs are appropriate for a user to enter a new generic expense
            btnDelete.Visibility = Visibility.Hidden;// there is no longer an expense of generic to delete so the delete button must be unaccessible
        }
    }
  }

