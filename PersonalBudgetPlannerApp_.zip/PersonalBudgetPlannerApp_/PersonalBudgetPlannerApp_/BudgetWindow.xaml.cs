﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PersonalBudgetPlannerApp_
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            lblIncLeft.Content = "";
            lblMon.Content = "";
            ExpenseList newList = new ExpenseList();// create an empty list
            Savings newSavings = new Savings();//creates an emty savings object
            UserBudget.currentBudget = new Budget("", 0, newList,newSavings);// set currentBudget to instance of Budget object to avoid 
                                                                             // NullReferenceException for the Budget object itself and for ExpenseList of Budget
            currentPage.Content = new IncomeMonthYear();//set current page to income by default
        }
     
        bool savingsDeducted = false;//bool to store if the savings has been chosen to be deducted from income by user

        public bool returnSavingsdeducted() //returns savings deducted, used by savings page to check is a savings has been deducted from income
        {
            return savingsDeducted;
        }

        public void setSavingsDedcuted(bool input) //sets input value to savingsdeducted. called by savings page when a savings has been removed and is thus not deducted anymore
        {
            savingsDeducted = input;
        }

        public void setLiveIncome()// sets value to total income left live txb 
        {
            double remMoney = UserBudget.currentBudget.remMoney();// store remaining money of current user budget to a variable
            lblIncLeft.Content = remMoney + ""; // set this remaining money to text of roral income left txb
            lblIncLeft.Foreground = new SolidColorBrush(Colors.Azure);
            if (remMoney < 0)//if remaining money is less than 0 make txb text colour red
            {
                lblIncLeft.Foreground = new SolidColorBrush(Colors.Red);
            }
            else
            {
                if (remMoney == 0)//make txb text colour orange if remaining money is 0
                {
                    lblIncLeft.Foreground = new SolidColorBrush(Colors.Orange);
                }
            }

        }

        public void setLiveIncomeSavingsExpense()// sets value to total income left live txb if user chooses to deduct savings from income
        {
            double remMoney = UserBudget.currentBudget.deductSavings();// store remaining money of current user budget to a variable
            lblIncLeft.Content = remMoney + ""; // set this remaining money to text of toral income left txb
            if (remMoney < 0)//if remaining money is less than 0 make txb text colour red
            {
                lblIncLeft.Foreground = new SolidColorBrush(Colors.Red);
            }
            else
            {
                if (remMoney == 0)//make txb text colour orange if remaining money is 0
                {
                    lblIncLeft.Foreground = new SolidColorBrush(Colors.Orange);
                }
            }
            savingsDeducted = true;

        }

        public bool checkUserBudgetNull() //checks if there is no current budget made by user yet
        {
            bool output = false;
            if (UserBudget.currentBudget.Month == "")// if month has no characters then user has not made an income and month yet
            {
                output = true;
            }
            return output;
        }

        public void setMonth()//sets txbMonth text to users current Budget month
        {
            lblMon.Content = UserBudget.currentBudget.Month;
        }
        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);//close all open windows
        }

        private void Tg_Btn_Checked(object sender, RoutedEventArgs e)
        {
            currentPage.Opacity = 0.33; //set frame opacity lower as menu bar is open
        }

        private void Tg_Btn_Unchecked(object sender, RoutedEventArgs e)
        {
            currentPage.Opacity = 1;//menu bar is closed so opacity must be normal
        }

        private void ListViewItem_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_Btn.IsChecked == true) //if menu bar is open dont show tool tips else show them
            {
                tt_inc.Visibility = Visibility.Collapsed;
                tt_generic.Visibility = Visibility.Collapsed;
                tt_property.Visibility = Visibility.Collapsed;
                tt_vehicle.Visibility = Visibility.Collapsed;
                tt_savings.Visibility = Visibility.Collapsed;
                tt_BudgetReport.Visibility = Visibility.Collapsed;
            }
            else
            {
                tt_inc.Visibility = Visibility.Visible;
                tt_generic.Visibility = Visibility.Visible;
                tt_property.Visibility = Visibility.Visible;
                tt_vehicle.Visibility = Visibility.Visible;
                tt_savings.Visibility = Visibility.Visible;
                tt_BudgetReport.Visibility = Visibility.Visible;
            }
        }

        private void BG_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Tg_Btn.IsChecked= false;
        }

        private void incMonYear_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {        
          currentPage.Content = new IncomeMonthYear(); //opens new income and month page in frame
         //Adapted from :https://www.youtube.com/watch?v=aBh0weP1bmo
         // Date: 18 May
         //Author: illford grammar school

        }



        private void Property_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (checkUserBudgetNull() == false)//opens property expense page or displays error if user hasnt entered income and month yet
            {
                currentPage.Content = new PropertyExpense();
                
            }
            else
            {
                MessageBox.Show("You have not selected a Month and income. Please do so before making an expense", "No Income and Month made", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            
        }

        private void Generic_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (checkUserBudgetNull() == false)//opens generic expense pageor displays error if user hasnt entered income and month yet
            {
                currentPage.Content = new GenericExpensesPage();

            }
            else
            {
                MessageBox.Show("You have not selected a Month and income. Please do so before making an expense", "No Income and Month made", MessageBoxButton.OK, MessageBoxImage.Error);
            }
           
        }

        private void Savings_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            currentPage.Content = new SavingsPage(); // opens savings page
        }

    
        private void Vehicle_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (checkUserBudgetNull() == false)//opens vehicle expense pageor displays error if user hasnt entered income and month yet
            {
                currentPage.Content = new VehicleExpensePage();

            }
            else
            {
                MessageBox.Show("You have not selected a Month and income. Please do so before making an expense", "No Income and Month made", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            
        }

        private void BudgetReport_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            currentPage.Content = new BudgetReportPage(); //opens budget report
        }
    }
}
